-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Giu 03, 2025 alle 16:06
-- Versione del server: 10.4.32-MariaDB
-- Versione PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `progetto_costruzione`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `attivita`
--

CREATE TABLE `attivita` (
  `id_attivita` int(11) NOT NULL,
  `id_progetto` int(11) NOT NULL,
  `nome_attivita` varchar(10) DEFAULT NULL,
  `descrizione` text DEFAULT NULL,
  `stato` enum('In Corso','Sospesa','Conclusa','Non Iniziata') DEFAULT 'Non Iniziata',
  `id_responsabile` int(11) NOT NULL,
  `costo_effettivo` decimal(10,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `attivita`
--

INSERT INTO `attivita` (`id_attivita`, `id_progetto`, `nome_attivita`, `descrizione`, `stato`, `id_responsabile`, `costo_effettivo`) VALUES
(1, 1, 'Pavimento', 'Costruire la zona del pavimento con il legno fornito', 'Conclusa', 16, 645.00),
(2, 1, 'Costruire ', 'costruire muri di mattone', 'In Corso', 15, 0.00),
(3, 1, 'costruzion', 'tetto in legno di quercia', 'In Corso', 16, 0.00),
(4, 2, 'Costruzion', 'Legno di alta qualità di Abete', 'Conclusa', 16, 300.00),
(5, 2, 'Costruzion', 'Legno di alta qualità di Abete', 'In Corso', 16, 0.00),
(6, 2, 'Costruzion', 'Definire palizzata ', 'Conclusa', 16, 400.00),
(11, 1, 'Costruzion', 'Costruzione del secondo piano con camere da letto e bagni', 'Non Iniziata', 16, 0.00),
(12, 10, 'Primi 10 k', 'pista bianca', 'Conclusa', 15, 300.00);

-- --------------------------------------------------------

--
-- Struttura della tabella `aziende`
--

CREATE TABLE `aziende` (
  `id_azienda` int(11) NOT NULL,
  `nome_azienda` varchar(255) NOT NULL,
  `indirizzo` varchar(255) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `email_aziendale` varchar(20) DEFAULT NULL,
  `partita_iva` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `aziende`
--

INSERT INTO `aziende` (`id_azienda`, `nome_azienda`, `indirizzo`, `telefono`, `email_aziendale`, `partita_iva`) VALUES
(1, 'CasaSRL', 'Via Costruzione 3', '1234567891', 'casasrl@costr.it', '11111111111'),
(2, 'CantiereSRL', NULL, NULL, NULL, NULL),
(4, 'ConstructSPA', 'Via Società 2', '2456324567', 'constructSPA@azienda', '12345234512');

-- --------------------------------------------------------

--
-- Struttura della tabella `compiti`
--

CREATE TABLE `compiti` (
  `id_compito` int(11) NOT NULL,
  `id_attivita` int(11) NOT NULL,
  `descrizione` text NOT NULL,
  `stato` enum('Non Iniziato','In Corso','Completato','Sospeso') DEFAULT 'Non Iniziato',
  `id_operaio` int(11) NOT NULL,
  `costo_effettivo` decimal(10,2) DEFAULT 0.00,
  `ore_lavorate` decimal(5,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `compiti`
--

INSERT INTO `compiti` (`id_compito`, `id_attivita`, `descrizione`, `stato`, `id_operaio`, `costo_effettivo`, `ore_lavorate`) VALUES
(1, 1, 'Prendere le assi dal magazzino e posizionarle nella zona del pavimento', 'Completato', 3, 234.00, 3.00),
(4, 2, 'Posizionare mattoni e mettere cemento', '', 3, 0.00, 0.00),
(5, 4, 'Porta 1', 'Completato', 3, 0.00, 0.00),
(8, 1, 'Posizionare Le assi seguendo lo schema del documento fornito', 'In Corso', 3, 0.00, 0.00),
(9, 1, 'Prendere il legno dal magazzino per iniziare la pavimentazione', 'Completato', 3, 300.00, 0.00),
(10, 12, 'Prendi i materiali', 'Completato', 3, 300.00, 3.00);

-- --------------------------------------------------------

--
-- Struttura della tabella `materiali_attrezzature`
--

CREATE TABLE `materiali_attrezzature` (
  `id` int(11) NOT NULL,
  `nome` varchar(20) NOT NULL,
  `descrizione` text DEFAULT NULL,
  `quantita` int(11) NOT NULL DEFAULT 0,
  `unita_misura` varchar(6) DEFAULT NULL,
  `categoria` enum('Materiale','Attrezzatura') NOT NULL,
  `id_azienda` int(11) NOT NULL,
  `stato` enum('Disponibile','In Uso','Non Disponibile') NOT NULL DEFAULT 'Disponibile',
  `ubicazione` varchar(255) DEFAULT NULL,
  `scorta_minima` int(11) DEFAULT 0,
  `costo_unitario` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `materiali_attrezzature`
--

INSERT INTO `materiali_attrezzature` (`id`, `nome`, `descrizione`, `quantita`, `unita_misura`, `categoria`, `id_azienda`, `stato`, `ubicazione`, `scorta_minima`, `costo_unitario`) VALUES
(4, 'Legno', 'Legno di alta qualità di Abete', 58, 'kg', 'Materiale', 1, 'Disponibile', 'Magazzino 1 ', 300, 40.00),
(5, 'Sega circolare', 'elettrica', 1, NULL, 'Attrezzatura', 1, 'Disponibile', 'Magazzino 1 ', 2, 234.00),
(6, 'Trapano ', 'Elettrico ', 2, NULL, 'Attrezzatura', 1, 'Disponibile', 'Magazzino 2', 1, 345.00),
(7, 'Cemento', 'Nessuna', 46, 'kg', 'Attrezzatura', 1, 'Disponibile', 'Magazzino 1 ', 35, 345.00),
(11, 'Mattoni', 'Nessuna', 0, 'kg', 'Materiale', 1, 'Disponibile', 'Magazzino 2', 20, 20.00),
(14, 'Acciaio', 'Inossidabile', 40, 'kg', 'Materiale', 1, 'Disponibile', 'Magazzino 2', 600, 30.00);

-- --------------------------------------------------------

--
-- Struttura della tabella `messaggi`
--

CREATE TABLE `messaggi` (
  `id_messaggio` int(11) NOT NULL,
  `id_mittente` int(11) NOT NULL,
  `id_destinatario` int(11) NOT NULL,
  `oggetto` varchar(20) NOT NULL,
  `contenuto` text NOT NULL,
  `data_invio` datetime DEFAULT current_timestamp(),
  `letto` tinyint(1) DEFAULT 0,
  `data_letto` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `messaggi`
--

INSERT INTO `messaggi` (`id_messaggio`, `id_mittente`, `id_destinatario`, `oggetto`, `contenuto`, `data_invio`, `letto`, `data_letto`) VALUES
(5, 3, 16, 'Aggiornamento ore la', 'Le assi sono in cantiere', '2025-05-08 21:49:46', 1, '2025-06-02 19:37:56'),
(6, 2, 16, 'Nuovo Progetto ', 'Possiamo iniziare?', '2025-06-02 19:37:44', 1, '2025-06-02 19:37:56'),
(7, 3, 15, 'Aggiornamento ore la', 'Prese', '2025-06-02 21:08:42', 0, NULL),
(8, 3, 15, 'Aggiornamento ore la', 'Prese', '2025-06-02 21:11:56', 0, NULL);

-- --------------------------------------------------------

--
-- Struttura della tabella `movimenti_materiali`
--

CREATE TABLE `movimenti_materiali` (
  `id_movimento` int(11) NOT NULL,
  `id_risorsa` int(11) NOT NULL,
  `id_mittente` int(11) DEFAULT NULL,
  `id_destinatario` int(11) DEFAULT NULL,
  `id_compito` int(11) DEFAULT NULL,
  `quantita` int(11) NOT NULL,
  `data_richiesta` datetime NOT NULL DEFAULT current_timestamp(),
  `tipo` enum('Entrata','Reso','Scarto','Uscita') NOT NULL,
  `stato` enum('In Attesa','Approvato','Rifiutato') DEFAULT 'In Attesa',
  `note` text DEFAULT NULL,
  `risposta` text DEFAULT NULL,
  `data_risposta` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `movimenti_materiali`
--

INSERT INTO `movimenti_materiali` (`id_movimento`, `id_risorsa`, `id_mittente`, `id_destinatario`, `id_compito`, `quantita`, `data_richiesta`, `tipo`, `stato`, `note`, `risposta`, `data_risposta`) VALUES
(28, 4, 16, 17, 1, 23, '2025-05-11 11:28:46', 'Uscita', 'Approvato', 'wadwd', 'Si', '2025-05-11 11:51:35'),
(29, 4, 16, 17, 1, 21, '2025-05-11 11:52:19', 'Uscita', 'Rifiutato', 'fsef', 'no', '2025-05-11 11:53:41'),
(33, 4, 16, 17, 1, 2, '2025-05-11 12:05:09', 'Reso', 'Rifiutato', 'avanzo', 'no', '2025-05-11 17:26:29'),
(34, 4, 16, 17, 5, 1, '2025-05-11 12:05:36', 'Scarto', 'Approvato', 'd', 'si', '2025-05-11 17:26:35'),
(35, 4, 16, 17, 5, 2, '2025-05-11 12:06:06', 'Reso', 'Approvato', 'dwda', 'boh', '2025-05-11 17:26:41'),
(37, 11, 17, NULL, NULL, 34, '2025-05-30 17:02:29', 'Scarto', 'Approvato', 'Scarto del materiale (quantità impostata a 0)', NULL, NULL),
(41, 14, 17, NULL, NULL, 40, '2025-06-02 19:45:31', 'Entrata', 'Approvato', 'Aggiunta iniziale del materiale', NULL, NULL),
(42, 4, 16, 17, 5, 23, '2025-06-02 21:15:41', 'Uscita', 'Approvato', 'Yes', 'wa', '2025-06-02 21:16:27'),
(43, 4, 16, 17, 1, 2, '2025-06-02 21:16:07', 'Reso', 'Approvato', 'Ok', 'ok', '2025-06-02 21:16:33');

-- --------------------------------------------------------

--
-- Struttura della tabella `notifiche`
--

CREATE TABLE `notifiche` (
  `id_notifica` int(11) NOT NULL,
  `id_utente` int(11) NOT NULL,
  `tipo_notifica` varchar(255) NOT NULL,
  `messaggio` text NOT NULL,
  `link` varchar(255) DEFAULT NULL,
  `data_notifica` datetime DEFAULT current_timestamp(),
  `letto` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `notifiche`
--

INSERT INTO `notifiche` (`id_notifica`, `id_utente`, `tipo_notifica`, `messaggio`, `link`, `data_notifica`, `letto`) VALUES
(240, 31, 'Attenzione: ', 'Completa i dati della tua azienda per continuare.', 'gestione_azienda.php', '2025-05-12 17:07:27', 1),
(241, 31, 'Attenzione ', 'Completa i dati della tua azienda per continuare.', 'gestione_azienda.php', '2025-05-12 17:08:26', 1),
(242, 31, 'Attenzione ', 'Completa i dati della tua azienda per continuare.', 'gestione_azienda.php', '2025-05-12 17:08:28', 1),
(243, 31, 'Attenzione', 'Completa i dati della tua azienda per continuare.', 'gestione_azienda.php', '2025-05-12 17:08:42', 0),
(245, 5, 'Progetto Modificato', 'E\' stato modificato il progetto da te richiesto', 'gestione_progetti.php', '2025-05-12 19:17:44', 0),
(253, 5, 'Progetto Modificato', 'E\' stato modificato il progetto da te richiesto', 'gestione_progetti.php', '2025-05-12 22:12:22', 0),
(256, 5, 'Progetto Modificato', 'E\' stato modificato il progetto da te richiesto', 'gestione_progetti.php', '2025-05-12 22:12:45', 0),
(259, 5, 'Progetto Modificato', 'E\' stato modificato il progetto da te richiesto', 'gestione_progetti.php', '2025-05-12 22:16:48', 0),
(262, 5, 'Progetto Modificato', 'E\' stato modificato il progetto da te richiesto', 'gestione_progetti.php', '2025-05-12 22:17:39', 0),
(265, 5, 'Progetto Modificato', 'E\' stato modificato il progetto da te richiesto', 'gestione_progetti.php', '2025-05-12 22:17:47', 0),
(268, 5, 'Progetto Modificato', 'E\' stato modificato il progetto da te richiesto', 'gestione_progetti.php', '2025-05-12 22:17:55', 0),
(271, 5, 'Progetto Modificato', 'E\' stato modificato il progetto da te richiesto', 'gestione_progetti.php', '2025-05-12 22:18:24', 0),
(274, 5, 'Progetto Modificato', 'E\' stato modificato il progetto da te richiesto', 'gestione_progetti.php', '2025-05-12 22:21:24', 0),
(277, 5, 'Progetto Modificato', 'E\' stato modificato il progetto da te richiesto', 'gestione_progetti.php', '2025-05-12 22:22:03', 0),
(280, 5, 'Progetto Modificato', 'E\' stato modificato il progetto da te richiesto', 'gestione_progetti.php', '2025-05-12 22:22:14', 0),
(292, 5, 'Progetto Modificato', 'E\' stato modificato il progetto da te richiesto', 'gestione_progetti.php', '2025-05-12 22:24:21', 0),
(295, 5, 'Progetto Modificato', 'E\' stato modificato il progetto da te richiesto', 'gestione_progetti.php', '2025-05-12 22:24:27', 0),
(298, 5, 'Progetto Modificato', 'E\' stato modificato il progetto da te richiesto', 'gestione_progetti.php', '2025-05-12 22:24:31', 0),
(301, 5, 'Progetto Modificato', 'E\' stato modificato il progetto da te richiesto', 'gestione_progetti.php', '2025-05-12 22:24:38', 0),
(304, 5, 'Progetto Modificato', 'E\' stato modificato il progetto da te richiesto', 'gestione_progetti.php', '2025-05-12 22:24:45', 0),
(307, 5, 'Progetto Modificato', 'E\' stato modificato il progetto da te richiesto', 'gestione_progetti.php', '2025-05-12 22:34:55', 0),
(310, 5, 'Nuovo Progetto', 'E\' stato sviluppato il progetto da te richiesto', 'gestione_progetti.php', '2025-05-12 22:47:03', 0),
(318, 5, 'Progetto Modificato', 'E\' stato modificato il progetto da te richiesto', 'gestione_progetti.php', '2025-05-12 22:53:19', 0),
(323, 3, 'Nuovo Compito ', 'Sei stato assegnato al compito di un\'attività', 'gestione_compiti.php', '2025-05-12 22:54:53', 0),
(324, 3, 'Nuovo Compito ', 'Sei stato assegnato al compito di un\'attività', 'gestione_compiti.php', '2025-05-12 22:55:02', 0),
(325, 3, 'Modifica Compito', 'Sono stati modificati alcuni parametri del tuo compito', 'gestione_compiti.php', '2025-05-12 22:55:21', 0),
(326, 3, 'Modifica Compito', 'Sono stati modificati alcuni parametri del tuo compito', 'gestione_compiti.php', '2025-05-12 22:55:26', 0),
(328, 3, 'Modifica Compito', 'Sono stati modificati alcuni parametri del tuo compito', 'gestione_compiti.php', '2025-05-12 22:56:59', 0),
(332, 5, 'Progetto Modificato', 'E\' stato modificato il progetto da te richiesto', 'gestione_progetti.php', '2025-05-15 21:08:28', 0),
(335, 5, 'Progetto Modificato', 'E\' stato modificato il progetto da te richiesto', 'gestione_progetti.php', '2025-05-15 21:08:57', 0),
(338, 5, 'Progetto Modificato', 'E\' stato modificato il progetto da te richiesto', 'gestione_progetti.php', '2025-05-15 21:09:12', 0),
(343, 3, 'Nuovo Compito ', 'Sei stato assegnato al compito di un\'attività', 'gestione_compiti.php', '2025-05-15 21:31:59', 0),
(362, 32, 'Attenzione', 'Completa i dati della tua azienda per continuare.', 'gestione_azienda.php', '2025-05-30 17:17:59', 0),
(363, 32, 'Attenzione', 'Completa i dati della tua azienda per continuare.', 'gestione_azienda.php', '2025-05-30 17:18:39', 0),
(364, 32, 'Attenzione', 'Completa i dati della tua azienda per continuare.', 'gestione_azienda.php', '2025-05-30 17:18:41', 0),
(365, 32, 'Attenzione', 'Completa i dati della tua azienda per continuare.', 'gestione_azienda.php', '2025-05-30 17:19:18', 0),
(366, 2, 'Scorta materiale insufficiente', 'La quantità del materiale \"Legno\" \r\n            è inferiore alla scorta minima.', 'gestione_mat_e_attr.php', '2025-06-02 18:04:03', 1),
(367, 2, 'Scorta materiale insufficiente', 'La quantità del materiale \"Mattoni\" \r\n            è inferiore alla scorta minima.', 'gestione_mat_e_attr.php', '2025-06-02 18:04:03', 1),
(368, 1, 'Scorta materiale insufficiente', 'La quantità del materiale \"Legno\" \r\n            è inferiore alla scorta minima.', 'gestione_mat_e_attr.php', '2025-06-02 18:06:23', 1),
(369, 1, 'Scorta materiale insufficiente', 'La quantità del materiale \"Mattoni\" \r\n            è inferiore alla scorta minima.', 'gestione_mat_e_attr.php', '2025-06-02 18:06:23', 1),
(376, 5, 'Progetto Modificato', 'E\' stato modificato il progetto da te richiesto', 'gestione_progetti.php', '2025-06-02 19:39:51', 0),
(378, 14, 'Progetto Eliminato', 'Il progetto al quale eri stato assegnato è stato elimato', 'gestione_progetti.php', '2025-06-02 19:39:55', 1),
(379, 5, 'Progetto Eliminato', 'E\' stato eliminato il progetto da te richiesto', 'gestione_progetti.php', '2025-06-02 19:39:55', 0),
(381, 26, 'Nuovo Progetto', 'E\' stato sviluppato il progetto da te richiesto', 'gestione_progetti.php', '2025-06-02 19:40:15', 0),
(383, 26, 'Progetto Eliminato', 'E\' stato eliminato il progetto da te richiesto', 'gestione_progetti.php', '2025-06-02 19:40:24', 0),
(384, 2, 'Scorta materiale insufficiente', 'La quantità del materiale \"Legno\" \r\n            è inferiore alla scorta minima.', 'gestione_mat_e_attr.php', '2025-06-02 19:41:35', 1),
(385, 2, 'Scorta materiale insufficiente', 'La quantità del materiale \"Mattoni\" \r\n            è inferiore alla scorta minima.', 'gestione_mat_e_attr.php', '2025-06-02 19:41:35', 1),
(386, 2, 'Scorta materiale insufficiente', 'La quantità del materiale \"Legno\" \r\n            è inferiore alla scorta minima.', 'gestione_mat_e_attr.php', '2025-06-02 19:41:48', 1),
(387, 2, 'Scorta materiale insufficiente', 'La quantità del materiale \"Mattoni\" \r\n            è inferiore alla scorta minima.', 'gestione_mat_e_attr.php', '2025-06-02 19:41:48', 1),
(400, 3, 'Nuovo Compito ', 'Sei stato assegnato al compito di un\'attività', 'gestione_compiti.php', '2025-06-02 21:03:21', 0),
(401, 3, 'Modifica Compito', 'Sono stati modificati alcuni parametri del tuo compito', 'gestione_compiti.php', '2025-06-02 21:03:38', 0),
(403, 26, 'Nuovo Progetto', 'E\' stato sviluppato il progetto da te richiesto', 'gestione_progetti.php', '2025-06-02 21:05:37', 0),
(406, 3, 'Nuovo Compito ', 'Sei stato assegnato al compito di un\'attività', 'gestione_compiti.php', '2025-06-02 21:08:11', 0),
(407, 15, 'Ore Lavorate', 'Sono state inserite nuove ore lavorate per il compito dell\'attività \r\n            \"Primi 10 k\".', 'gestione_compiti.php', '2025-06-02 21:08:42', 0),
(409, 16, 'Progetto Modificato', 'Ti è stato assegnato un nuovo Progetto', 'gestione_progetti.php', '2025-06-02 21:09:11', 0),
(410, 26, 'Progetto Modificato', 'E\' stato modificato il progetto da te richiesto', 'gestione_progetti.php', '2025-06-02 21:09:11', 0),
(411, 16, 'Progetto Modificato', 'Sei stato rimosso dall\'incarico di Responsabile del progetto', 'gestione_progetti.php', '2025-06-02 21:09:11', 0),
(412, 15, 'Modifica Attività', 'Sono stati modificati alcuni parametri della tua attività', 'gestione_attivita.php', '2025-06-02 21:09:37', 0),
(413, 3, 'Modifica Compito', 'Sono stati modificati alcuni parametri del tuo compito', 'gestione_compiti.php', '2025-06-02 21:10:54', 0),
(414, 15, 'Ore Lavorate', 'Sono state inserite nuove ore lavorate per il compito dell\'attività \r\n            \"Primi 10 k\".', 'gestione_compiti.php', '2025-06-02 21:11:56', 0),
(415, 3, 'Modifica Compito', 'Sono stati modificati alcuni parametri del tuo compito', 'gestione_compiti.php', '2025-06-02 21:12:16', 0),
(416, 3, 'Modifica Compito', 'Sono stati modificati alcuni parametri del tuo compito', 'gestione_compiti.php', '2025-06-02 21:13:09', 0),
(417, 15, 'Modifica Attività', 'Sono stati modificati alcuni parametri della tua attività', 'gestione_attivita.php', '2025-06-02 21:13:33', 0),
(418, 16, 'Progetto Modificato', 'Ti è stato assegnato un nuovo Progetto', 'gestione_progetti.php', '2025-06-02 21:13:50', 0),
(419, 26, 'Progetto Modificato', 'E\' stato modificato il progetto da te richiesto', 'gestione_progetti.php', '2025-06-02 21:13:50', 0),
(420, 16, 'Progetto Modificato', 'Sei stato rimosso dall\'incarico di Responsabile del progetto', 'gestione_progetti.php', '2025-06-02 21:13:50', 0),
(424, 17, 'Scorta materiale insufficiente', 'La quantità del materiale \"Legno\" \r\n            è inferiore alla scorta minima.', 'gestione_mat_e_attr.php', '2025-06-02 21:14:54', 0),
(425, 17, 'Scorta materiale insufficiente', 'La quantità del materiale \"Mattoni\" \r\n            è inferiore alla scorta minima.', 'gestione_mat_e_attr.php', '2025-06-02 21:14:54', 0),
(426, 17, 'Scorta materiale insufficiente', 'La quantità del materiale \"Acciaio\" \r\n            è inferiore alla scorta minima.', 'gestione_mat_e_attr.php', '2025-06-02 21:14:54', 0),
(427, 17, 'Scorta materiale insufficiente', 'La quantità del materiale \"Legno\" \r\n            è inferiore alla scorta minima.', 'gestione_mat_e_attr.php', '2025-06-02 21:14:57', 0),
(428, 17, 'Scorta materiale insufficiente', 'La quantità del materiale \"Mattoni\" \r\n            è inferiore alla scorta minima.', 'gestione_mat_e_attr.php', '2025-06-02 21:14:57', 0),
(429, 17, 'Scorta materiale insufficiente', 'La quantità del materiale \"Acciaio\" \r\n            è inferiore alla scorta minima.', 'gestione_mat_e_attr.php', '2025-06-02 21:14:57', 0),
(430, 17, 'Nuova Richiesta Materiale', 'Hai ricevuto una nuova richiesta di materiale da parte di Alma D\'Angelo', 'gestione_mat_e_attr.php', '2025-06-02 21:15:41', 0),
(431, 17, 'Richiesta di Reso', 'È stata ricevuta una richiesta di reso dal Responsabile Alma D\'Angelo', 'gestione_mat_e_attr.php', '2025-06-02 21:16:07', 0),
(432, 17, 'Scorta materiale insufficiente', 'La quantità del materiale \"Legno\" \r\n            è inferiore alla scorta minima.', 'gestione_mat_e_attr.php', '2025-06-02 21:16:19', 0),
(433, 17, 'Scorta materiale insufficiente', 'La quantità del materiale \"Mattoni\" \r\n            è inferiore alla scorta minima.', 'gestione_mat_e_attr.php', '2025-06-02 21:16:19', 0),
(434, 17, 'Scorta materiale insufficiente', 'La quantità del materiale \"Acciaio\" \r\n            è inferiore alla scorta minima.', 'gestione_mat_e_attr.php', '2025-06-02 21:16:19', 0),
(435, 17, 'Scorta materiale insufficiente', 'La quantità del materiale \"Legno\" \r\n            è inferiore alla scorta minima.', 'gestione_mat_e_attr.php', '2025-06-02 21:16:27', 0),
(436, 17, 'Scorta materiale insufficiente', 'La quantità del materiale \"Mattoni\" \r\n            è inferiore alla scorta minima.', 'gestione_mat_e_attr.php', '2025-06-02 21:16:27', 0),
(437, 17, 'Scorta materiale insufficiente', 'La quantità del materiale \"Acciaio\" \r\n            è inferiore alla scorta minima.', 'gestione_mat_e_attr.php', '2025-06-02 21:16:27', 0),
(438, 16, 'Richiesta di movimento Approvata: ', 'La tua richiesta di movimento dei materiali è stata approvata dal Magazziniere Marco Divano', 'richieste_mat.php', '2025-06-02 21:16:27', 0),
(439, 17, 'Scorta materiale insufficiente', 'La quantità del materiale \"Legno\" \r\n            è inferiore alla scorta minima.', 'gestione_mat_e_attr.php', '2025-06-02 21:16:27', 0),
(440, 17, 'Scorta materiale insufficiente', 'La quantità del materiale \"Mattoni\" \r\n            è inferiore alla scorta minima.', 'gestione_mat_e_attr.php', '2025-06-02 21:16:27', 0),
(441, 17, 'Scorta materiale insufficiente', 'La quantità del materiale \"Acciaio\" \r\n            è inferiore alla scorta minima.', 'gestione_mat_e_attr.php', '2025-06-02 21:16:27', 0),
(442, 17, 'Scorta materiale insufficiente', 'La quantità del materiale \"Legno\" \r\n            è inferiore alla scorta minima.', 'gestione_mat_e_attr.php', '2025-06-02 21:16:33', 0),
(443, 17, 'Scorta materiale insufficiente', 'La quantità del materiale \"Mattoni\" \r\n            è inferiore alla scorta minima.', 'gestione_mat_e_attr.php', '2025-06-02 21:16:33', 0),
(444, 17, 'Scorta materiale insufficiente', 'La quantità del materiale \"Acciaio\" \r\n            è inferiore alla scorta minima.', 'gestione_mat_e_attr.php', '2025-06-02 21:16:33', 0),
(445, 16, 'Richiesta di movimento Approvata: ', 'La tua richiesta di movimento dei materiali è stata approvata dal Magazziniere Marco Divano', 'richieste_mat.php', '2025-06-02 21:16:33', 0),
(446, 17, 'Scorta materiale insufficiente', 'La quantità del materiale \"Legno\" \r\n            è inferiore alla scorta minima.', 'gestione_mat_e_attr.php', '2025-06-02 21:16:33', 0),
(447, 17, 'Scorta materiale insufficiente', 'La quantità del materiale \"Mattoni\" \r\n            è inferiore alla scorta minima.', 'gestione_mat_e_attr.php', '2025-06-02 21:16:33', 0),
(448, 17, 'Scorta materiale insufficiente', 'La quantità del materiale \"Acciaio\" \r\n            è inferiore alla scorta minima.', 'gestione_mat_e_attr.php', '2025-06-02 21:16:33', 0);

-- --------------------------------------------------------

--
-- Struttura della tabella `progetti`
--

CREATE TABLE `progetti` (
  `id_progetto` int(11) NOT NULL,
  `nome_progetto` varchar(255) NOT NULL,
  `descrizione` text DEFAULT NULL,
  `data_inizio` date DEFAULT NULL,
  `data_scadenza` date DEFAULT NULL,
  `budget` decimal(10,2) DEFAULT NULL,
  `id_committente` int(11) NOT NULL,
  `id_responsabile` int(11) NOT NULL,
  `id_azienda` int(11) NOT NULL,
  `stato` enum('Non Iniziato','Completato','In sospeso','Annullato','In Corso') NOT NULL DEFAULT 'Non Iniziato',
  `costo_effettivo` decimal(10,2) DEFAULT 0.00,
  `data_fine_effettiva` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `progetti`
--

INSERT INTO `progetti` (`id_progetto`, `nome_progetto`, `descrizione`, `data_inizio`, `data_scadenza`, `budget`, `id_committente`, `id_responsabile`, `id_azienda`, `stato`, `costo_effettivo`, `data_fine_effettiva`) VALUES
(1, 'Casa', 'Casa di mattoni con finestre vetrate', '2025-04-11', '2025-04-16', 10000.00, 5, 15, 1, 'Completato', 8000.00, '2025-05-12'),
(2, 'Villetta', 'Villa di due piani e 3 bagni ', '2025-04-22', '2025-04-26', 3558.00, 5, 15, 1, 'Completato', 30000.00, '2025-06-02'),
(6, 'Spa', 'Costruzione di una Spa per un centro benessere ', '2025-05-09', '2025-05-16', 23500.00, 26, 14, 1, 'Annullato', 0.00, NULL),
(7, 'Costruzione Appartamento', 'costruire un appartamento con due bagni, un salone, cucina e due camere da letto', '2025-05-13', '2025-05-17', 30000.00, 26, 29, 4, 'In sospeso', 0.00, NULL),
(10, 'Pista di Atterraggio', '40km', '2025-06-02', '2025-06-03', 400000.00, 26, 16, 1, 'Completato', 300.00, '2025-06-02');

-- --------------------------------------------------------

--
-- Struttura della tabella `utenti`
--

CREATE TABLE `utenti` (
  `id_utente` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `cognome` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `tipo_utente` enum('Azienda','Dipendente Aziendale','Admin','Committente') NOT NULL,
  `stato` enum('Attivo','In Attesa','Eliminato','Sospeso') DEFAULT 'In Attesa',
  `ruolo` enum('Amministratore Aziendale','Operaio','Responsabile','Magazziniere','Contabile') DEFAULT NULL,
  `id_azienda` int(11) DEFAULT NULL,
  `data_registrazione` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dump dei dati per la tabella `utenti`
--

INSERT INTO `utenti` (`id_utente`, `nome`, `cognome`, `email`, `password`, `tipo_utente`, `stato`, `ruolo`, `id_azienda`, `data_registrazione`) VALUES
(1, 'Giovanbattista', 'DAmico', 'giovanbattista.damico1@studenti.unicampania.it', '$2y$10$ZqDII5c7Zo0ic0kQkNvAcevGficfpjg9k/MdIL2dEfPRjPq62lw4a', 'Admin', 'Attivo', '', NULL, '2025-03-29 17:59:15'),
(2, 'Mario', 'Rossi', 'ciao@esempio.it', '$2y$10$.UtaCnj0giVZY0X0Pi4wZOP1u2Y4tbAo3ro.CfMZy5HtpclTVJtU.', 'Azienda', 'Attivo', 'Amministratore Aziendale', 1, '2025-03-29 19:29:30'),
(3, 'Mario', 'Rosso', 'operaio3@operaio.it', '$2y$10$Hwun7lyn4NpG1AWdBbyvre2fBgw5JUkgCb8EafAUmVu31IlurM1kC', 'Dipendente Aziendale', 'Attivo', 'Operaio', 1, '2025-04-01 16:48:11'),
(5, 'Claudia', 'Mattei', 'committente@committente.it', '$2y$10$RPtNp4sk7rLeg/bZM4LB0efWaWFZkrT5ZetI2NkNnqqZk/41FdOKm', 'Committente', 'Attivo', '', NULL, '2025-04-03 09:52:18'),
(14, 'Giacomo', 'Rossi', 'responsabile1@azienda.it', '$2y$10$KOww3I9pOCj0Io.58ZkzkOXwz7lGwgFhgniVdmVCDjhzN2Wqb70Ca', 'Dipendente Aziendale', 'Attivo', 'Responsabile', 1, '2025-04-06 16:05:09'),
(15, 'Massimo', 'Di Benedetto', 'responsabile2@azienda.it', '$2y$10$Gyo4cf.ctlebqlyAHDJNmudY9Kun2q.kODzEINF1.oX0nIK9MpzgK', 'Dipendente Aziendale', 'Attivo', 'Responsabile', 1, '2025-04-09 16:19:39'),
(16, 'Alma', 'D\'Angelo', 'responsabile3@azienda.it', '$2y$10$c2VRZ8POgVGs1iM8t812rOmD6Ow54tsQODA5qj2CJ3qmf6xGTkAgS', 'Dipendente Aziendale', 'Attivo', 'Responsabile', 1, '2025-04-10 15:48:48'),
(17, 'Marco', 'Divano', 'magazziniere1@azienda.it', '$2y$10$x12RthqivZ5vbXj9uDF4j.p9975qQljH4bX41SG0RoDwCpU9.mTdO', 'Dipendente Aziendale', 'Attivo', 'Magazziniere', 1, '2025-04-14 11:21:57'),
(18, 'Anna', 'D\'Angelo', 'contabile1@azienda1.it', '$2y$10$8iMVyuX1HpOR3S7.kLXgR.M4BihB5/9Qa5LU0QrUKSpDIPSSZSwi.', 'Dipendente Aziendale', 'Attivo', 'Contabile', 1, '2025-04-27 08:57:22'),
(19, 'Massimo', 'Cartone', 'azienda2@azienda.it', '$2y$10$UWbzCYxGZ6lwv3YJRe1cBOM9rQL0wIZOEIkNVPcgXfaNndoU7pC9G', 'Azienda', 'Attivo', '', 2, '2025-04-27 09:24:51'),
(26, 'Giacomo', 'Rosso', 'committente2@committenti.it', '$2y$10$9eNSORW5G97488ZiYgoD3u0iwbS0MPUm/BRKKdKn3jryjSvgRucNK', 'Committente', 'Attivo', NULL, NULL, '2025-04-27 14:32:05'),
(27, 'Mario', 'Saccone', 'amministratoreAziendale3@esempio.it', '$2y$10$zSpvm6pfRFL/1ARe4NZ1MOpFCm2HJswVOQU2Hq5gtlm0VP.nv1C7S', 'Azienda', 'Attivo', 'Amministratore Aziendale', 4, '2025-05-05 16:11:59'),
(28, 'Mario', 'Sordi', 'committente3@committenti.it', '$2y$10$ufMoobJBJjnyu222CTkEquiMtf0bc03ecIvXaUZQfM0JGz3O1L5wW', 'Committente', 'Attivo', NULL, NULL, '2025-05-05 16:13:45'),
(29, 'Salvatore', 'Costanzo', 'operaio2@esempio.it', '$2y$10$ec6WZZzjTjymZclMLb61ZOGFMzLtDLQTUkhp6sAf.4Gqir.FbdmPO', 'Dipendente Aziendale', 'Attivo', 'Responsabile', 4, '2025-05-05 16:14:25'),
(30, 'Giano', 'Solano', 'committente4@committenti.it', '$2y$10$gy66Efo9gqBKf5tZCu2CyOiQFFiFcOLTYklRdQtmnLBrGrxt7E.tG', 'Committente', 'Attivo', NULL, NULL, '2025-05-05 22:21:29'),
(31, 'Mario', 'Abbate', 'amministratoreAziendale4@esempio.it', '$2y$10$dXOlbNavpftvUaJVJ769a.tyRIvIhVCFT8h6Dqg.h6PJpqJDdMi.K', 'Azienda', 'Attivo', 'Amministratore Aziendale', 5, '2025-05-12 15:07:17'),
(32, 'Giovanni', 'De Carli', 'azienda3@aziende.it', '$2y$10$WHkq7Hy6m9tS7kVBYxh90eU5ftyuwgH2o8UqW1kjH38.oyKLVDgNC', 'Azienda', 'Attivo', 'Amministratore Aziendale', 6, '2025-05-30 15:14:22'),
(33, 'Alma', 'Martini', 'azienda4@azienda.it', '$2y$10$hnBRcrmevYPZmlmtjRvof.CDIhCYKT9i.dLXkBPcmBS1llzHKilQW', 'Azienda', 'Eliminato', 'Amministratore Aziendale', 7, '2025-06-02 15:47:45');

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `attivita`
--
ALTER TABLE `attivita`
  ADD PRIMARY KEY (`id_attivita`),
  ADD KEY `id_progetto` (`id_progetto`),
  ADD KEY `id_responsabile` (`id_responsabile`);

--
-- Indici per le tabelle `aziende`
--
ALTER TABLE `aziende`
  ADD PRIMARY KEY (`id_azienda`);

--
-- Indici per le tabelle `compiti`
--
ALTER TABLE `compiti`
  ADD PRIMARY KEY (`id_compito`),
  ADD KEY `id_attivita` (`id_attivita`),
  ADD KEY `id_assegnatario` (`id_operaio`);

--
-- Indici per le tabelle `materiali_attrezzature`
--
ALTER TABLE `materiali_attrezzature`
  ADD PRIMARY KEY (`id`),
  ADD KEY `proprietario_id` (`id_azienda`);

--
-- Indici per le tabelle `messaggi`
--
ALTER TABLE `messaggi`
  ADD PRIMARY KEY (`id_messaggio`),
  ADD KEY `id_mittente` (`id_mittente`),
  ADD KEY `id_destinatario` (`id_destinatario`);

--
-- Indici per le tabelle `movimenti_materiali`
--
ALTER TABLE `movimenti_materiali`
  ADD PRIMARY KEY (`id_movimento`),
  ADD KEY `id_materiale` (`id_risorsa`),
  ADD KEY `fk_mittente` (`id_mittente`),
  ADD KEY `fk_destinatario` (`id_destinatario`),
  ADD KEY `fk_compito` (`id_compito`);

--
-- Indici per le tabelle `notifiche`
--
ALTER TABLE `notifiche`
  ADD PRIMARY KEY (`id_notifica`),
  ADD KEY `id_utente` (`id_utente`);

--
-- Indici per le tabelle `progetti`
--
ALTER TABLE `progetti`
  ADD PRIMARY KEY (`id_progetto`),
  ADD KEY `committente_id` (`id_committente`),
  ADD KEY `responsabile_id` (`id_responsabile`),
  ADD KEY `progetti_ibfk_3` (`id_azienda`);

--
-- Indici per le tabelle `utenti`
--
ALTER TABLE `utenti`
  ADD PRIMARY KEY (`id_utente`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT per le tabelle scaricate
--

--
-- AUTO_INCREMENT per la tabella `attivita`
--
ALTER TABLE `attivita`
  MODIFY `id_attivita` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT per la tabella `aziende`
--
ALTER TABLE `aziende`
  MODIFY `id_azienda` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT per la tabella `compiti`
--
ALTER TABLE `compiti`
  MODIFY `id_compito` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT per la tabella `materiali_attrezzature`
--
ALTER TABLE `materiali_attrezzature`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT per la tabella `messaggi`
--
ALTER TABLE `messaggi`
  MODIFY `id_messaggio` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT per la tabella `movimenti_materiali`
--
ALTER TABLE `movimenti_materiali`
  MODIFY `id_movimento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT per la tabella `notifiche`
--
ALTER TABLE `notifiche`
  MODIFY `id_notifica` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=449;

--
-- AUTO_INCREMENT per la tabella `progetti`
--
ALTER TABLE `progetti`
  MODIFY `id_progetto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT per la tabella `utenti`
--
ALTER TABLE `utenti`
  MODIFY `id_utente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- Limiti per le tabelle scaricate
--

--
-- Limiti per la tabella `attivita`
--
ALTER TABLE `attivita`
  ADD CONSTRAINT `attivita_ibfk_1` FOREIGN KEY (`id_progetto`) REFERENCES `progetti` (`id_progetto`) ON DELETE CASCADE,
  ADD CONSTRAINT `attivita_ibfk_2` FOREIGN KEY (`id_responsabile`) REFERENCES `utenti` (`id_utente`) ON DELETE CASCADE;

--
-- Limiti per la tabella `compiti`
--
ALTER TABLE `compiti`
  ADD CONSTRAINT `compiti_ibfk_1` FOREIGN KEY (`id_attivita`) REFERENCES `attivita` (`id_attivita`) ON DELETE CASCADE,
  ADD CONSTRAINT `compiti_ibfk_2` FOREIGN KEY (`id_operaio`) REFERENCES `utenti` (`id_utente`) ON DELETE CASCADE;

--
-- Limiti per la tabella `materiali_attrezzature`
--
ALTER TABLE `materiali_attrezzature`
  ADD CONSTRAINT `materiali_attrezzature_ibfk_1` FOREIGN KEY (`id_azienda`) REFERENCES `utenti` (`id_utente`) ON DELETE CASCADE;

--
-- Limiti per la tabella `messaggi`
--
ALTER TABLE `messaggi`
  ADD CONSTRAINT `messaggi_ibfk_1` FOREIGN KEY (`id_mittente`) REFERENCES `utenti` (`id_utente`),
  ADD CONSTRAINT `messaggi_ibfk_2` FOREIGN KEY (`id_destinatario`) REFERENCES `utenti` (`id_utente`);

--
-- Limiti per la tabella `movimenti_materiali`
--
ALTER TABLE `movimenti_materiali`
  ADD CONSTRAINT `fk_compito` FOREIGN KEY (`id_compito`) REFERENCES `compiti` (`id_compito`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_destinatario` FOREIGN KEY (`id_destinatario`) REFERENCES `utenti` (`id_utente`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk_mittente` FOREIGN KEY (`id_mittente`) REFERENCES `utenti` (`id_utente`) ON DELETE SET NULL,
  ADD CONSTRAINT `movimenti_materiali_ibfk_1` FOREIGN KEY (`id_risorsa`) REFERENCES `materiali_attrezzature` (`id`);

--
-- Limiti per la tabella `notifiche`
--
ALTER TABLE `notifiche`
  ADD CONSTRAINT `notifiche_ibfk_1` FOREIGN KEY (`id_utente`) REFERENCES `utenti` (`id_utente`) ON DELETE CASCADE;

--
-- Limiti per la tabella `progetti`
--
ALTER TABLE `progetti`
  ADD CONSTRAINT `progetti_ibfk_1` FOREIGN KEY (`id_committente`) REFERENCES `utenti` (`id_utente`),
  ADD CONSTRAINT `progetti_ibfk_2` FOREIGN KEY (`id_responsabile`) REFERENCES `utenti` (`id_utente`),
  ADD CONSTRAINT `progetti_ibfk_3` FOREIGN KEY (`id_azienda`) REFERENCES `aziende` (`id_azienda`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
